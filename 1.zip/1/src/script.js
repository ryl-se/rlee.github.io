function hidePage() {
    document.body.innerHTML = '';  // 清空整个页面内容
}

